import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import request from './request';
import Row from './Row';
//one component and reuse it.
//A snippet of code that wokrs on specific condition/variable - gives a hook 
function App() {

  return (
    <div className='App'>


<Row title = "NETFLIX ORIGNAL" fetchUrl={request.fetchNetflixOrignals}/>
<Row title = "Trending Now " fetchUrl={request.fetchTrending}/>


    </div>//install ES7 REACT extentions 
  );

}

export default App
