//getting all movies 
const Api_key = "8dd11bf675ec17a2331e0513326e913f";


export default{
fetchTrending : `/trending/all/week?api_key=${Api_key}&language=en-US`,

fetchNetflixOrignals:`/discover/tv?api_key=${Api_key}&with_network=213`,

fetchTopRated : `/movies/top_rated?api_key=${Api_key}&language=en=US`,

fetchActionMovies : `/discover/movie?api_key=${Api_key}&with_network=28`,

fetchComedyMovies:`/discover/movie?api_key=${Api_key}&with_network=35`,

fetchHorroMovies:`/discover/movie?api_key=${Api_key}&with_network=27`,

fetchRomanceMovies:`/discover/movie?api_key=${Api_key}&with_network=10749`,

fetchDocumentariesMovies:`/discover/movie?api_key=${Api_key}&with_network=99`,
}
