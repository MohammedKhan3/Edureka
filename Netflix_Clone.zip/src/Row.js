import React, { useEffect, useState } from 'react';
import axios from './axios';

function Row({title, fetchUrl}) {
   // Keep track using state 
   const [movies, setMovies] = useState([]);

   useEffect(() => {
      // Function to fetch data
      async function fetchData() {
         const request = await axios.get(fetchUrl);

         setMovies(request.data.results);

         // Corrected console.log statement
         console.log(request.data.results);

         return request;
      }  

      // Call the fetchData function
      fetchData();
   }, [fetchUrl]); // Dependency array to re-run the effect when fetchUrl changes

   return (
      <div>
         <h2>{title}</h2>
       
      </div>
   )
}

export default Row;
