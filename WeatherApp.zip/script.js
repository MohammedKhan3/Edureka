document.addEventListener('DOMContentLoaded', () => {
    const states = ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"];
    const selectElement = document.getElementById('stateSelector');

    states.forEach(state => {
        const option = document.createElement('option');
        option.value = state;
        option.innerText = state;
        selectElement.appendChild(option);
    });

    selectElement.addEventListener('change', () => {
        fetchData(selectElement.value);
    });
});

async function fetchData(state) {
    const apiKey = "3b21b50710da60abfcaa1a8642e39597";
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${state}&appid=${apiKey}&units=metric`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        displayWeather(data);
    } catch (error) {
        document.getElementById('weatherOutput').innerText = 'Api Failed to Load';
        console.error('Error fetching data: ', error);
    }
}

function displayWeather(data) {
    const weather = document.getElementById('weatherOutput');
    weather.innerHTML = `
        <h2>Weather in ${data.name}</h2>
        <p>Temperature: ${data.main.temp}°C</p>
        <p>Humidity: ${data.main.humidity}%</p>
        <p>Wind Speed: ${data.wind.speed} m/s</p>
    `;
}
